package com.riwi.primeraweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerawebApplicationTests {

	@Test
	void contextLoads() {
	}

}
