package com.riwi.gestor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorApplicationTests {

	@Test
	void contextLoads() {
	}

}
